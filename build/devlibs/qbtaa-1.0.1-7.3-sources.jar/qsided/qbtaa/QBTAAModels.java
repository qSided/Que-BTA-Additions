package qsided.qbtaa;

import net.minecraft.client.render.EntityRenderDispatcher;
import net.minecraft.client.render.TileEntityRenderDispatcher;
import net.minecraft.client.render.block.color.BlockColorDispatcher;
import net.minecraft.client.render.block.model.BlockModelDispatcher;
import net.minecraft.client.render.block.model.BlockModelTransparent;
import net.minecraft.client.render.item.model.ItemModelDispatcher;

import net.minecraft.core.util.helper.Side;
import turniplabs.halplibe.helper.ModelHelper;
import turniplabs.halplibe.util.ModelEntrypoint;

import static qsided.qbtaa.QBTAAMod.MOD_ID;
import static qsided.qbtaa.QBTAAMod.LOGGER;

// Importing blocks and items

import static qsided.qbtaa.QBTAABlocks.*;

public class QBTAAModels implements ModelEntrypoint {

	// If the dispatcher arg is conflicting with the override, please update your halplibe to 5.1.2
	// Go to the file gradle.properties > halplibe_version=5.1.2
	// Then in the right tab if intelliJ > Gradle > Sync All Gradle Projects (it updates de halplibe)

	// Please register the model entrypoint in fabric.mod.json:

	// "initModels": [
	//	"deivethedev.testmod.TestModels"
	// ],

	@Override
	public void initBlockModels(BlockModelDispatcher dispatcher) {

		// The block variable is being imported from TestBlocks, look in the top of the script

		// The ModelHelper is just an easier way to create models provided by HalpLibe

		// Creating a standard block model (full block) an "applying" to the block data.
		ModelHelper.setBlockModel(stained_glass, () -> new BlockModelGlassPainted<>(stained_glass).onRenderLayer(1)
			.setTex(0, MOD_ID + ":block/glass/white", Side.sides));



		//ModelHelper.setBlockModel(red_stained_glass, () -> new BlockModelTransparent<>(stained_glass, false).onRenderLayer(1)
		//	.setTex(0, MOD_ID + ":block/black_stained_glass", Side.sides));
		//ModelHelper.setBlockModel(green_stained_glass, () -> new BlockModelTransparent<>(stained_glass, false).onRenderLayer(1)
		//	.setTex(0, MOD_ID + ":block/black_stained_glass", Side.sides));
		//ModelHelper.setBlockModel(brown_stained_glass, () -> new BlockModelTransparent<>(stained_glass, false).onRenderLayer(1)
		//	.setTex(0, MOD_ID + ":block/black_stained_glass", Side.sides));
		//ModelHelper.setBlockModel(blue_stained_glass, () -> new BlockModelTransparent<>(stained_glass, false).onRenderLayer(1)
		//	.setTex(0, MOD_ID + ":block/black_stained_glass", Side.sides));
		//ModelHelper.setBlockModel(purple_stained_glass, () -> new BlockModelTransparent<>(stained_glass, false).onRenderLayer(1)
		//	.setTex(0, MOD_ID + ":block/black_stained_glass", Side.sides));
		//ModelHelper.setBlockModel(cyan_stained_glass, () -> new BlockModelTransparent<>(stained_glass, false).onRenderLayer(1)
		//	.setTex(0, MOD_ID + ":block/black_stained_glass", Side.sides));
		//ModelHelper.setBlockModel(light_gray_stained_glass, () -> new BlockModelTransparent<>(stained_glass, false).onRenderLayer(1)
		//	.setTex(0, MOD_ID + ":block/black_stained_glass", Side.sides));
		//ModelHelper.setBlockModel(gray_stained_glass, () -> new BlockModelTransparent<>(stained_glass, false).onRenderLayer(1)
		//	.setTex(0, MOD_ID + ":block/black_stained_glass", Side.sides));
		//ModelHelper.setBlockModel(pink_stained_glass, () -> new BlockModelTransparent<>(stained_glass, false).onRenderLayer(1)
		//	.setTex(0, MOD_ID + ":block/black_stained_glass", Side.sides));
		//ModelHelper.setBlockModel(lime_stained_glass, () -> new BlockModelTransparent<>(stained_glass, false).onRenderLayer(1)
		//	.setTex(0, MOD_ID + ":block/black_stained_glass", Side.sides));
		//ModelHelper.setBlockModel(yellow_stained_glass, () -> new BlockModelTransparent<>(stained_glass, false).onRenderLayer(1)
		//	.setTex(0, MOD_ID + ":block/black_stained_glass", Side.sides));
		//ModelHelper.setBlockModel(light_blue_stained_glass, () -> new BlockModelTransparent<>(stained_glass, false).onRenderLayer(1)
		//	.setTex(0, MOD_ID + ":block/black_stained_glass", Side.sides));
		//ModelHelper.setBlockModel(magenta_stained_glass, () -> new BlockModelTransparent<>(stained_glass, false).onRenderLayer(1)
		//	.setTex(0, MOD_ID + ":block/black_stained_glass", Side.sides));
		//ModelHelper.setBlockModel(orange_stained_glass, () -> new BlockModelTransparent<>(stained_glass, false).onRenderLayer(1)
		//	.setTex(0, MOD_ID + ":block/black_stained_glass", Side.sides));
		//ModelHelper.setBlockModel(white_stained_glass, () -> new BlockModelTransparent<>(stained_glass, false).onRenderLayer(1)
		//	.setTex(0, MOD_ID + ":block/black_stained_glass", Side.sides));

		LOGGER.info("Block Models initialized.");
	}

	@Override
	public void initItemModels(ItemModelDispatcher dispatcher) {

		// ALMOST the same as creating a standard block model (look up)
		//ModelHelper.setItemModel(tutorialItem, () -> {
		//	ItemModelStandard model = new ItemModelStandard(tutorialItem, MOD_ID);
		//	model.icon = TextureRegistry.getTexture(new NamespaceID(MOD_ID, "item/tutorial_item"));
		//	return model;
		//});

		LOGGER.info("Item Models initialized.");
	}

	@Override
	public void initEntityModels(EntityRenderDispatcher dispatcher) {}

	@Override
	public void initTileEntityModels(TileEntityRenderDispatcher dispatcher) {}

	@Override
	public void initBlockColors(BlockColorDispatcher dispatcher) {}
}
