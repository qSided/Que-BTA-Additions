package qsided.qbtaa;

import net.minecraft.core.block.Block;
import net.minecraft.core.block.material.Material;
import net.minecraft.core.block.tag.BlockTags;
import net.minecraft.core.sound.BlockSounds;
import turniplabs.halplibe.helper.BlockBuilder;

import static qsided.qbtaa.QBTAAMod.MOD_ID; // need to static because it is just one variable
import static qsided.qbtaa.QBTAAMod.LOGGER; // same

public class QBTAABlocks {

	// START HERE
	// For each block you will need a texture, a name, and an id.
	// the id could be set manually, but if in the future you need to change them, you would need to do this manually as well
	// so we need make it automatically
	// go to TestConfig class, change the values and go back here

	// Importing the starting id that we set in TestConfig
	private static int startingID = QBTAAConfig.CFG.getInt("IDs.startingBlockID");
	private static int nextID() {return startingID++;} // just a little function to increase the id every new item

	// Declaring blocks

	public static Block<?> stained_glass; // basic block

	//public static Block<?> red_stained_glass; // basic block
	//public static Block<?> green_stained_glass; // basic block
	//public static Block<?> brown_stained_glass; // basic block
	//public static Block<?> blue_stained_glass; // basic block
	//public static Block<?> purple_stained_glass; // basic block
	//public static Block<?> cyan_stained_glass; // basic block
	//public static Block<?> light_gray_stained_glass; // basic block
	//public static Block<?> gray_stained_glass; // basic block
	//public static Block<?> pink_stained_glass; // basic block
	//public static Block<?> lime_stained_glass; // basic block
	//public static Block<?> yellow_stained_glass; // basic block
	//public static Block<?> light_blue_stained_glass; // basic block
	//public static Block<?> magenta_stained_glass; // basic block
	//public static Block<?> orange_stained_glass; // basic block
	//public static Block<?> white_stained_glass; // basic block

	public static void initBlocks() {

		// Creating a simple block with no functionality:

		// Creating a BlockBuilder
		// The BlockBuilder is just an easier way to create blocks provided by HalpLibe

		BlockBuilder builder = new BlockBuilder(MOD_ID) // MOD_ID is being imported from TestMod, look in the top of the script.

			// Setting properties of the block. Check the possible properties: Ctrl + LeftClick in BlockBuilder
			.setBlockSound(BlockSounds.GLASS)
			.setHardness(0.3F)
			.setLightOpacity(0)
			.setTags(BlockTags.MINEABLE_BY_PICKAXE, BlockTags.EXTENDS_MOTION_SENSOR_RANGE);

			// Sets the block tags (the game uses it to interact with the block). Check the possible tags: Ctrl + LeftClick in BlockTags
			//.addTags(BlockTags.MINEABLE_BY_PICKAXE);

		// The build function just create an Item with the created builder properties
		stained_glass = builder.build("block.stained_glass", "block/stained_glass", nextID(), b -> new BlockLogicGlassPainted(b, Material.glass));

		//red_stained_glass = builder.build("block.qbtaa", "block/red_stained_glass", nextID(), b -> new BlockLogicGlass(b, Material.glass));
		//green_stained_glass = builder.build("block.qbtaa", "block/green_stained_glass", nextID(), b -> new BlockLogicGlass(b, Material.glass));
		//brown_stained_glass = builder.build("block.qbtaa", "block/brown_stained_glass", nextID(), b -> new BlockLogicGlass(b, Material.glass));
		//blue_stained_glass = builder.build("block.qbtaa", "block/blue_stained_glass", nextID(), b -> new BlockLogicGlass(b, Material.glass));
		//purple_stained_glass = builder.build("block.qbtaa", "block/purple_stained_glass", nextID(), b -> new BlockLogicGlass(b, Material.glass));
		//cyan_stained_glass = builder.build("block.qbtaa", "block/cyan_stained_glass", nextID(), b -> new BlockLogicGlass(b, Material.glass));
		//light_gray_stained_glass = builder.build("block.qbtaa", "block/light_gray_stained_glass", nextID(), b -> new BlockLogicGlass(b, Material.glass));
		//gray_stained_glass = builder.build("block.qbtaa", "block/gray_stained_glass", nextID(), b -> new BlockLogicGlass(b, Material.glass));
		//pink_stained_glass = builder.build("block.qbtaa", "block/pink_stained_glass", nextID(), b -> new BlockLogicGlass(b, Material.glass));
		//lime_stained_glass = builder.build("block.qbtaa", "block/lime_stained_glass", nextID(), b -> new BlockLogicGlass(b, Material.glass));
		//yellow_stained_glass = builder.build("block.qbtaa", "block/yellow_stained_glass", nextID(), b -> new BlockLogicGlass(b, Material.glass));
		//light_blue_stained_glass = builder.build("block.qbtaa", "block/light_blue_stained_glass", nextID(), b -> new BlockLogicGlass(b, Material.glass));
		//magenta_stained_glass = builder.build("block.qbtaa", "block/magenta_stained_glass", nextID(), b -> new BlockLogicGlass(b, Material.glass));
		//orange_stained_glass = builder.build("block.qbtaa", "block/orange_stained_glass", nextID(), b -> new BlockLogicGlass(b, Material.glass));
		//white_stained_glass = builder.build("block.qbtaa", "block/white_stained_glass", nextID(), b -> new BlockLogicGlass(b, Material.glass));
		//								traslationKey      name               id        block logic ( you don't need to know for now, just that )
		// 									 |													    ( material sets the sound when placing the block)
		// 									 V
		// 								go to resources > lang > testmod > en_US.lang to see how it works

		// So far you have only registered the block, it appears in the inventory but does not have a texture. For that check TestModels > initBlockModels

		LOGGER.info("Blocks initialized.");
	}
}
