package qsided.qbtaa;

import net.minecraft.core.block.Blocks;
import net.minecraft.core.item.Item;
import net.minecraft.core.item.ItemStack;
import net.minecraft.core.item.Items;
import turniplabs.halplibe.helper.RecipeBuilder;
import turniplabs.halplibe.util.RecipeEntrypoint;

import static qsided.qbtaa.QBTAAMod.LOGGER;
import static qsided.qbtaa.QBTAAMod.MOD_ID;

import static qsided.qbtaa.QBTAABlocks.*;

// Same as the Models
// Please register the model entrypoint in fabric.mod.json:
// "recipesReady": [
// "deivethedev.tutorialmod.TutorialRecipes"
// ],

public class QBTAARecipes implements RecipeEntrypoint { // don't forget to implement the RecipeEntrypoint

	@Override
	public void onRecipesReady() { // Why the function name is onRecipesReady instead of initRecipes I don't know.

		ItemStack whiteDye = Items.DYE.getDefaultStack();
		whiteDye.setMetadata(15);
		//ItemStack redDye = Items.DYE.getDefaultStack();
		//redDye.setMetadata(1);
		//Item greenDye = Items.DYE;
		//greenDye.getDefaultStack().setMetadata(2);
		//Item brownDye = Items.DYE;
		//brownDye.getDefaultStack().setMetadata(3);
		//Item blueDye = Items.DYE;
		//blueDye.getDefaultStack().setMetadata(4);
		//Item purpleDye = Items.DYE;
		//purpleDye.getDefaultStack().setMetadata(5);
		//Item cyanDye = Items.DYE;
		//cyanDye.getDefaultStack().setMetadata(6);
		//Item lGrayDye = Items.DYE;
		//lGrayDye.getDefaultStack().setMetadata(7);
		//Item grayDye = Items.DYE;
		//grayDye.getDefaultStack().setMetadata(8);
		//Item pinkDye = Items.DYE;
		//pinkDye.getDefaultStack().setMetadata(9);
		//Item limeDye = Items.DYE;
		//limeDye.getDefaultStack().setMetadata(10);
		//Item yellowDye = Items.DYE;
		//yellowDye.getDefaultStack().setMetadata(11);
		//Item lBlueDye = Items.DYE;
		//lBlueDye.getDefaultStack().setMetadata(12);
		//Item magentaDye = Items.DYE;
		//magentaDye.getDefaultStack().setMetadata(13);
		//Item orangeDye = Items.DYE;
		//orangeDye.getDefaultStack().setMetadata(14);
		//Item whiteDye = Items.DYE;
		//whiteDye.getDefaultStack().setMetadata(15);

		//ItemStack whiteSG = stained_glass.asItem().getDefaultStack();
		//whiteSG.setMetadata(0);
		//ItemStack redSG = new ItemStack(stained_glass.asItem(), 8, 1);
		//redSG.setMetadata(1);
		//ItemStack greenSG = new ItemStack(stained_glass, 8);
		//greenSG.setMetadata(2);
		//ItemStack brownSG = new ItemStack(stained_glass, 8);
		//brownSG.setMetadata(3);
		//ItemStack blueSG = new ItemStack(stained_glass, 8);
		//blueSG.setMetadata(4);
		//ItemStack purpleSG = new ItemStack(stained_glass, 8);
		//purpleSG.setMetadata(5);
		//ItemStack cyanSG = new ItemStack(stained_glass, 8);
		//cyanSG.setMetadata(6);
		//ItemStack lGraySG = new ItemStack(stained_glass, 8);
		//lGraySG.setMetadata(7);
		//ItemStack graySG = new ItemStack(stained_glass, 8);
		//graySG.setMetadata(8);
		//ItemStack pinkSG = new ItemStack(stained_glass, 8);
		//pinkSG.setMetadata(9);
		//ItemStack limeSG = new ItemStack(stained_glass, 8);
		//limeSG.setMetadata(10);
		//ItemStack yellowSG = new ItemStack(stained_glass, 8);
		//yellowSG.setMetadata(11);
		//ItemStack lBlueSG = new ItemStack(stained_glass, 8);
		//lBlueSG.setMetadata(12);
		//ItemStack magentaSG = new ItemStack(stained_glass, 8);
		//magentaSG.setMetadata(13);
		//ItemStack orangeSG = new ItemStack(stained_glass, 8);
		//orangeSG.setMetadata(14);
		//ItemStack whiteSG = new ItemStack(stained_glass.getDefaultStack().getItem(), 8);
		//whiteSG.setMetadata(15);

		// Registering a fuel
		//LookupFuelFurnace.instance.addFuelEntry(woodChips.id, 20);
		//						   				     Δ	       Δ
		//                                        item id    ticks per fuel (minecraft runs at 20 ticks per second and vanilla coal lasts 1600 ticks)


		// Crafting recipe

		// Like BlockBuilder
		RecipeBuilder.Shaped(MOD_ID)
			.setShape(
				"BBB",
				"BCB",
				"BBB")
			.addInput('B', Blocks.GLASS)
			.addInput('C', whiteDye)// you choose the letter and the input item (if you and vanilla/bta blocks use Blocks.COBBLESTONE)
			.create("white_stained_glass", new ItemStack(stained_glass, 8));
		RecipeBuilder.Shapeless(MOD_ID)
			.addInput(Items.DOOR_GLASS)
			.addInput(Items.DOOR_GLASS)
			.addInput(whiteDye)// you choose the letter and the input item (if you and vanilla/bta blocks use Blocks.COBBLESTONE)
			.create("white_stained_glass_door", new ItemStack(QBTAAItems.stained_glass_door, 2));

		//			      Δ                           Δ        Δ
		//			 recipe name               output item   quantity

		// Furnace Recipe

		//RecipeBuilder.Furnace(MOD_ID)
		//	.setInput(banana) // Item you want to cook
		//	.create("cooked_banana", new ItemStack(cookedBanana, 1));


		LOGGER.info("Recipes initialized.");
	}

	@Override
	public void initNamespaces() {
		RecipeBuilder.initNameSpace(MOD_ID);
	}

}
